package com.Niharika.CarRentalSystem.service;


import com.Niharika.CarRentalSystem.entity.Car;
import com.Niharika.CarRentalSystem.repository.CarRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CarService {
	
    @Autowired
	private CarRepository carRepository;
    //Get all cars
    public List<Car> getAllCars(){
    	return carRepository.findAll();
    }
    //Get car by ID
    public Optional<Car> getCarById(Long id){
    	return carRepository.findById(id);
    }
    //Add or update a car
    public Car updateCar(Long id, Car car) {
    	return carRepository.save(car);
    }
    //Delete a car
    public void deleteCar(Long id) {
    	carRepository.deleteById(id);
    	
    }
	public Car saveCar(Car car) {
	
		return carRepository.save(car);
	}

}
